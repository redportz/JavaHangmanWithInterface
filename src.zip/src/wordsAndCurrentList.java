import java.util.ArrayList;

public class wordsAndCurrentList {
    public static int twoWordsAgo;

    public static int previousWord=-1;
    public static int currentWord=-1;
    public static int currentCategory=-1;
    public static boolean newCategory;
    public static ArrayList<String> listOfWords = new ArrayList<>();
}
