

public class Main {
    public static void main(String[] args) {

        MenuScreen menuScreen= new MenuScreen();
//    WinWindow winWindow= new WinWindow();
//        GamePlayScreen gamePlayScreen= new GamePlayScreen(2);
//        LossWindow lossWindow= new LossWindow();
    }

}